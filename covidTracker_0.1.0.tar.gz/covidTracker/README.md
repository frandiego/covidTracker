# covidTracker
Dashboard to track covid 19 pandemia using public dataset published by Johns Hopkins University
